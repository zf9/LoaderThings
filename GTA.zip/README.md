# ImGui Loader Base
 A Base For a Loader or literally anything.
