#include "ui.hh"
#include "../globals.hh"
#include "../imgui/imgui.h"
#include "../imgui/imgui_internal.h"
#include "../UI-Header/Theme-Header.h"
#include "../UI-Header/Update.h"


#include "../Cheat-Byte/bytetofile.hpp"
#include "../Cheat-Byte/Bytes/LSCHax.h"
#include "../Cheat-Byte/Bytes/BincoHaXUI.h"

#include "../UI-Header/CT.h"


#pragma warning(disable:4996)
#define _CRT_SECURE_NO_WARNINGS


bool CheatInject1 = false;
bool CheatInject2 = false;
bool CheatInject3 = false;
bool CheatInject4 = false;
bool CheatInject5 = false;
bool CheatInject6 = false;
bool CheatInject7 = false;
bool CheatInject8 = false;
bool CheatInject9 = false;

inline bool FileExists(const std::string& name) {
    struct stat buffer;
    return (stat(name.c_str(), &buffer) == 0);
}

std::string LSCHax = "C:\\ProgramData\\LSCHax.exe";
std::string BincoHaXUI = "C:\\ProgramData\\BincoHaXUI.exe";

void ui::render() {
    if (!globals.active) return;
    std::string MB_Title = "Cyclone Cheats";

    ImGui::SetNextWindowPos(ImVec2(window_pos.x, window_pos.y), ImGuiCond_Once);
    ImGui::SetNextWindowSize(ImVec2(window_size.x, window_size.y));
    ImGui::SetNextWindowBgAlpha(1.0f);

    ImGui::Begin(window_title, &globals.active, window_flags);
    {
        if (ImGui::Button("kiddions", ImVec2(284, 40)))
        {
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918442318716104754/modest-menu.exe", "C:\\ProgramData\\modest-menu.exe", 0, NULL);
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918442318552518676/config.json", "C:\\ProgramData\\config.json", 0, NULL);
            system("C:\\ProgramData\\modest-menu.exe");

        }
        if (ImGui::Button("Guylets", ImVec2(284, 40)))
        {
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918439254495993886/System.Drawing.Common.dll", "C:\\ProgramData\\System.Drawing.Common.dll", 0, NULL);
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918439254328242196/PlayerdexDll.dll", "C:\\ProgramData\\PlayerdexDll.dll", 0, NULL);
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918439254168846336/Guylets_Playerdex.runtimeconfig.json", "C:\\ProgramData\\Guylets_Playerdex.runtimeconfig.json", 0, NULL);
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918439253971701760/Guylets_Playerdex.exe", "C:\\ProgramData\\Guylets_Playerdex.exe", 0, NULL);
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918439253426446346/Guylets_Playerdex.dll", "C:\\ProgramData\\Guylets_Playerdex.dll", 0, NULL);
            system("C:\\ProgramData\\Guylets_Playerdex.exe");

        }
        if (ImGui::Button("BincoHaXUI", ImVec2(284, 40)))
        {
            URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917703041635987496/918438451274186803/scriptmetadata.meta", "C:\\ProgramData\\scriptmetadata.meta", 0, NULL);
            if (!FileExists(BincoHaXUI)) utils::CreateFileFromMemory(BincoHaXUI, reinterpret_cast<const char*>(BincoHaXUIBytes), sizeof(BincoHaXUIBytes));
            system("C:\\ProgramData\\BincoHaXUI.exe");
        }
        if (ImGui::Button("LSCHax", ImVec2(284, 40)))
        {
            if (!FileExists(LSCHax)) utils::CreateFileFromMemory(LSCHax, reinterpret_cast<const char*>(LSCHaxBytes), sizeof(LSCHaxBytes));
            system("C:\\ProgramData\\LSCHax.exe");
        }
        if (ImGui::Button("CasinoHack_l33", ImVec2(284, 40)))
        {
            FILE* file;
            if (file = fopen("C:\\Program Files\\Cheat Engine 7.3\\Cheat Engine.exe", "r")) {
                fclose(file);
                MessageBox(0, "Found Cheat Engine 7.3", "", MB_OK);
                CasinoHack_l33tdude_unknowncheats();
            }
            else {
                FILE* filee;
                if (filee = fopen("C:\\Program Files\\Cheat Engine 7.1\\Cheat Engine.exe", "r")) {
                    fclose(filee);
                    MessageBox(0, "Found Cheat Engine 7.1", "", MB_OK);
                    CasinoHack_l33tdude_unknowncheats();
                }
                else {
                    FILE* fileee;
                    if (fileee = fopen("C:\\Program Files\\Cheat Engine 7.2\\Cheat Engine.exe", "r")) {
                        fclose(fileee);
                        MessageBox(0, "Found Cheat Engine 7.1", "", MB_OK);
                        CasinoHack_l33tdude_unknowncheats();
                    }
                    else {
                        FILE* fileeee;
                        if (fileeee = fopen("C:\\Program Files\\Cheat Engine 7.0\\Cheat Engine.exe", "r")) {
                            fclose(fileeee);
                            MessageBox(0, "Found Cheat Engine 7.0", "", MB_OK);
                            CasinoHack_l33tdude_unknowncheats();
                        }
                        else {
                            MessageBox(0, "Scanned For Cheat Engine 7.0 - 7.3!\nI Could not locate any. Try Pressing 'Install CE'", "", MB_OK);
                        }
                    }
                }
            }
        }
        if (ImGui::Button("GTA5TunersGenZ_v3", ImVec2(284, 40)))
        {
            FILE* file;
            if (file = fopen("C:\\Program Files\\Cheat Engine 7.3\\Cheat Engine.exe", "r")) {
                fclose(file);
                MessageBox(0, "Found Cheat Engine 7.3", "", MB_OK);
                GTA5TunersGenZ_v3();
            }
            else {
                FILE* filee;
                if (filee = fopen("C:\\Program Files\\Cheat Engine 7.1\\Cheat Engine.exe", "r")) {
                    fclose(filee);
                    MessageBox(0, "Found Cheat Engine 7.1", "", MB_OK);
                    GTA5TunersGenZ_v3();
                }
                else {
                    FILE* fileee;
                    if (fileee = fopen("C:\\Program Files\\Cheat Engine 7.2\\Cheat Engine.exe", "r")) {
                        fclose(fileee);
                        MessageBox(0, "Found Cheat Engine 7.1", "", MB_OK);
                        GTA5TunersGenZ_v3();
                    }
                    else {
                        FILE* fileeee;
                        if (fileeee = fopen("C:\\Program Files\\Cheat Engine 7.0\\Cheat Engine.exe", "r")) {
                            fclose(fileeee);
                            MessageBox(0, "Found Cheat Engine 7.0", "", MB_OK);
                            GTA5TunersGenZ_v3();
                        }
                        else {
                            MessageBox(0, "Scanned For Cheat Engine 7.0 - 7.3!\nI Could not locate any. Try Pressing 'Install CE'", "", MB_OK);
                        }
                    }
                }
            }
        }
        if (ImGui::Button("Join Discord", ImVec2(140, 40)))
        {
            ShellExecute(0, 0, "http://zf9.one/U/GT_Discord.html", 0, 0, SW_SHOW);
        }
        ImGui::SameLine();
        if (ImGui::Button("Reset Injection", ImVec2(140, 40)))
        {
            CheatInject1 = false;
            CheatInject2 = false;
            CheatInject3 = false;
            CheatInject4 = false;
            CheatInject5 = false;
            CheatInject6 = false;
            CheatInject7 = false;
            CheatInject8 = false;
            CheatInject9 = false;
            MessageBox(0, "Reset Injection Complete", MB_Title.c_str(), MB_OK);
        }
        if (ImGui::Button("Install CE", ImVec2(140, 40)))
        {
            URLDownloadToFileA(NULL, "https://github.com/cheat-engine/cheat-engine/releases/download/7.1/CheatEngine71.exe", "C:\\ProgramData\\CheatEngine71.exe", 0, NULL);
            system("C:\\ProgramData\\CheatEngine71.exe /VERYSILENT /NORESTART /NOCANDY");
        }
        ImGui::SameLine();
        if (ImGui::Button("?", ImVec2(140, 40)))
        {
            HamMafiaTheme_RandCol();

        }
    }
    ImGui::End();
}

void ui::init(LPDIRECT3DDEVICE9 device) {
    dev = device;
    HamMafiaTheme();
    // colors
    //ImGui::StyleColorsDark();

    A_Update();

	if (window_pos.x == 0) {
		RECT screen_rect{};
		GetWindowRect(GetDesktopWindow(), &screen_rect);
		screen_res = ImVec2(float(screen_rect.right), float(screen_rect.bottom));
		window_pos = (screen_res - window_size) * 0.5f;

		// init images here
	}
}