#pragma once
#include <urlmon.h>
#pragma comment(lib, "Urlmon.lib")
#pragma warning(disable:4996)
#define _CRT_SECURE_NO_WARNINGS

void GTA5TunersGenZ_v3()
{
	URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917518595674763357/917519598448959528/GTA5TunersGenZ_v3.0p1GNull_unknowncheats.me_.ct", "C:\\ProgramData\\GTA5TunersGenZ_v3.ct", 0, NULL);
	system("C:\\ProgramData\\GTA5TunersGenZ_v3.ct");

}

void CasinoHack_l33tdude_unknowncheats()
{
	URLDownloadToFileA(NULL, "https://cdn.discordapp.com/attachments/917518595674763357/917519611287724042/CasinoHack_l33tdude_unknowncheats.me_.ct", "C:\\ProgramData\\CasinoHack_l33tdude_unknowncheats.ct", 0, NULL);
	system("C:\\ProgramData\\GTA5TunersGenZ_v3.ct");

}