#pragma once
void A_Update()
{
    URLDownloadToFileA(NULL, "https://pastebin.com/raw/SFUD6U0m", "C:\\ProgramData\\LV.sex", 0, NULL);

    std::string LV;
    std::ifstream LVF("C:\\ProgramData\\LV.sex");
    while (getline(LVF, LV)) {
    }

    if (LV == "1.0") {

    }
    else {
        if (MessageBoxA(NULL, "Out of date loader!\nWould you like to update?", "", MB_YESNO) == IDYES)
        {
            URLDownloadToFileA(NULL, "http://zf9.one/U/CS_Loader.exe", "C:\\CS_Loader.exe", 0, NULL);
            MessageBoxA(NULL, "Updated Downloaded To C:\\CS_Loader.exe", "", MB_OK);
            exit(99);
        }
        else
        {
        }
    }
    LVF.close();
    remove("C:\\ProgramData\\LV.sex");
}